#include <stdio.h>
#include <stdlib.h>

#define MAX_NOS 10

typedef struct NetworkGraph {
    char mat_adj[MAX_NOS][MAX_NOS];
} ng;
